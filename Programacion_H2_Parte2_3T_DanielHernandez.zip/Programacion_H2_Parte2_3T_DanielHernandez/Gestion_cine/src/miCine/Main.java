package miCine;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("1. Ver peliculas");
            System.out.println("2. Agregar pelicula");
            System.out.println("3. Editar pelicula");
            System.out.println("4. Eliminar pelicula");
            System.out.println("5. Salir");
            System.out.print("Selecciona una opcion: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    PeliculaEAE.verPeliculas();
                    break;
                case 2:
                    PeliculaEAE.agregarPelicula();
                    break;
                case 3:
                    PeliculaEAE.editarPelicula();
                    break;
                case 4:
                    PeliculaEAE.eliminarPelicula();
                    break;
                case 5:
                    System.out.println("Saliendo");
                    break;
                default:
                    System.out.println("Opcion no válida.");
            }

        } while (opcion != 5);

        scanner.close();
    }
}

package miCine;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class PeliculaEAE {

    static Scanner scanner = new Scanner(System.in);

    public static void verPeliculas() {
        String query = "SELECT codigo, titulo, director, genero, duracion FROM peliculas";

        try (Connection conn = ConexionBD.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            System.out.printf("%-6s %-30s %-25s %-15s %-10s%n",
                    "Código", "Título", "Director", "Género", "Duración");

            while (rs.next()) {
                System.out.printf("%-6s %-30s %-25s %-15s %-10d%n",
                        rs.getString("codigo"),
                        rs.getString("titulo"),
                        rs.getString("director"),
                        rs.getString("genero"),
                        rs.getInt("duracion"));
            }

        } catch (Exception e) {
            System.out.println("Error al mostrar películas: " + e.getMessage());
        }
    }

    public static void agregarPelicula() {
        System.out.print("Código: ");
        String codigo = scanner.nextLine();

        System.out.print("Título: ");
        String titulo = scanner.nextLine();

        System.out.print("Director: ");
        String director = scanner.nextLine();

        System.out.print("Género: ");
        String genero = scanner.nextLine();

        System.out.print("Duración (minutos): ");
        int duracion = Integer.parseInt(scanner.nextLine());

        String query = "INSERT INTO peliculas (codigo, titulo, director, genero, duracion) " +
                       "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, codigo);
            stmt.setString(2, titulo);
            stmt.setString(3, director);
            stmt.setString(4, genero);
            stmt.setInt(5, duracion);

            stmt.executeUpdate();
            System.out.println("Película agregada correctamente.");

        } catch (Exception e) {
            System.out.println("Error al agregar película: " + e.getMessage());
        }
    }

    public static void editarPelicula() {
        System.out.print("Código de la película a editar: ");
        String codigo = scanner.nextLine();

        System.out.print("Nuevo título: ");
        String titulo = scanner.nextLine();

        System.out.print("Nuevo director: ");
        String director = scanner.nextLine();

        String query = "UPDATE peliculas SET titulo = ?, director = ? WHERE codigo = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, titulo);
            stmt.setString(2, director);
            stmt.setString(3, codigo);

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Película actualizada correctamente.");
            } else {
                System.out.println("No se encontró una película con ese código.");
            }

        } catch (Exception e) {
            System.out.println("Error al editar película: " + e.getMessage());
        }
    }

    public static void eliminarPelicula() {
        System.out.print("Código de la película a eliminar: ");
        String codigo = scanner.nextLine();

        String query = "DELETE FROM peliculas WHERE codigo = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, codigo);
            int filas = stmt.executeUpdate();

            if (filas > 0) {
                System.out.println("Película eliminada correctamente.");
            } else {
                System.out.println("No se encontró una película con ese código.");
            }

        } catch (Exception e) {
            System.out.println("Error al eliminar película: " + e.getMessage());
        }
    }
}

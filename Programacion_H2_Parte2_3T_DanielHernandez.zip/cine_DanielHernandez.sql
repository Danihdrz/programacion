create database cine_DanielHernandez;
use cine_DanielHernandez;
 
CREATE TABLE clasificaciones (
    id INT PRIMARY KEY,
    descripcion VARCHAR(50)
);
 CREATE TABLE peliculas (
    codigo VARCHAR(10) PRIMARY KEY,
    titulo VARCHAR(100),
    director VARCHAR(100),
    genero VARCHAR(50),
    duracion INT,
    id_clasificacion INT,
    FOREIGN KEY (id_clasificacion) REFERENCES clasificaciones(id)
);

INSERT INTO clasificaciones (id, descripcion) VALUES
(1, 'Apta para todo público'),
(2, 'Mayores de 13'),
(3, 'Mayores de 18');

INSERT INTO peliculas (codigo, titulo, director, genero, duracion, id_clasificacion) VALUES
('P001', 'Inception', 'Christopher Nolan', 'Ciencia Ficción', 148, 2),
('P002', 'El Rey León', 'Rob Minkoff', 'Animación', 89, 1),
('P003', 'John Wick', 'Chad Stahelski', 'Acción', 101, 3);

